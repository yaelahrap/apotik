const flashData = $('.flash-data').data('flashdata');

if (flashData) {
	Swal({
		title: 'Submenu ',
		text: 'Berhasil ' + flashData,
		type: 'success'
	});
}
