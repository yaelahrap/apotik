<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model
{
    public function hapusProduct($id)
    {
        $this->db->where('id', $id);
        $this->db->delete('v_cart');
    }
}