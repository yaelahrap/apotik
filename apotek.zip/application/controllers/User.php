<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller 
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('User_model', 'um');
        
    }

    public function index()
    {
        $data['title'] = 'Profile';
        $data['tbl_user'] = $this->db->get_where('tbl_user', ['email' => $this->session->userdata('email')])->row_array();
        
        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('user/index', $data);
        $this->load->view('templates/footer');

    }

    public function medicine()
    {
        $data['title'] = 'Medicine';
        $data['tbl_user'] = $this->db->get_where('tbl_user', ['email' => $this->session->userdata('email')])->row_array();
        
        $data['nama_obat'] = $this->db->get('tbl_obat')->result_array();

        $this->form_validation->set_rules('nama_obat', 'Medicine', 'required');
        $this->form_validation->set_rules('satuan', 'Satuan', 'required');
        $this->form_validation->set_rules('harga', 'Harga', 'required');
        $this->form_validation->set_rules('stok', 'Stock', 'required');
        
        if ( $this->form_validation->run() == false ) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('user/medicine', $data);
            $this->load->view('templates/footer');    
        } else {
            $data = [
                'nama_obat' => $this->input->post('nama_obat'),
                'satuan' => $this->input->post('satuan'),
                'harga' => $this->input->post('harga'),
                'stok' => $this->input->post('stok')
            ];
            $this->db->insert('tbl_obat', $data);
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">
            New menu added!
            </div>');
            redirect('user/medicine');
        }

    }

    public function edit()
    {
        $data['title'] = 'Edit Profile';
        $data['tbl_user'] = $this->db->get_where('tbl_user', ['email' => $this->session->userdata('email')])->row_array();

        $this->form_validation->set_rules('name', 'Full Name', 'required|trim');

        if ( $this->form_validation->run() == false ) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('user/edit', $data);
            $this->load->view('templates/footer'); 
        } else {
            $name = $this->input->post('name');
            $email = $this->input->post('email');

            // cek jika ada gambar yang akan diupload
            $upload_image = $_FILES['image']['name'];
            
            if ( $upload_image ) {
                $config['allowed_types'] = 'gif|jpg|png|jpeg';
                $config['max_size'] = 2048;
                $config['upload_path'] = './assets/img/profile';
                // $config['max_width'] = 892;
                // $config['max_height'] = 892;

                $this->load->library('upload', $config);

                if ( $this->upload->do_upload('image') ) {
                    $old_image = $data['tbl_user']['image'];
                    if ( $old_image != 'default.jpg' ) {
                        unlink(FCPATH . 'assets/img/profile/' . $old_image);
                    }

                    $new_image = $this->upload->data('file_name');
                    $this->db->set('image', $new_image);
                } else {
                    echo $this->upload->dispay_errors();
                }
            }

            $this->db->set('name', $name);
            $this->db->where('email', $email);
            $this->db->update('tbl_user');

            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">
            Your profile has been updated!
            </div>');
            redirect('user');
        }    
    }

    public function changePassword()
    {
        $data['title'] = 'Change Password';
        $data['tbl_user'] = $this->db->get_where('tbl_user', ['email' => $this->session->userdata('email')])->row_array();

        $this->form_validation->set_rules('current_password', 'Current Password', 'required|trim');
        $this->form_validation->set_rules('new_password1', 'New Password', 'required|trim|min_length[6]|matches[new_password2]');
        $this->form_validation->set_rules('new_password2', 'Confirm New Password', 'required|trim|min_length[6]|matches[new_password1]');
        
        if ( $this->form_validation->run() == false ) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('user/changepassword', $data);
            $this->load->view('templates/footer');      
        } else {
            $current_password = $this->input->post('current_password');
            $new_password = $this->input->post('new_password1');
            if ( !password_verify($current_password, $data['tbl_user']['password']) ) {
                $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">
                Wrong current password!
                </div>');
                redirect('user/changepassword');
            } else {
                if ( $current_password == $new_password ) {
                    $this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">
                    New password cannot be the same as current password!
                    </div>');
                    redirect('user/changepassword');
                } else {
                    // password sudah ok
                    $password_hash = password_hash($new_password, PASSWORD_DEFAULT);

                    $this->db->set('password', $password_hash);
                    $this->db->where('email', $this->session->userdata('email'));
                    $this->db->update('tbl_user');

                    $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">
                    Password change!
                    </div>');
                    redirect('user/changepassword');
                }
            }
        }

    }

    public function addCart()
    {
        $data['tbl_user'] = $this->db->get_where('tbl_user', ['email' => $this->session->userdata('email')])->row_array();
        
        $this->form_validation->set_rules('qty', 'Qty', 'required');

        if ( $this->form_validation->run() == false ) {
        
        } else {
            $harga = $this->input->post('harga');
            $qty = $this->input->post('qty');
            $subtotal = $harga*$qty;
            $data = [
                'id_obat' =>  $this->input->post('id_obat'),
                'nama_obat' =>  $this->input->post('nama_obat'),
                'harga' => $this->input->post('harga'),
                'qty' => $this->input->post('qty'),
                'subtotal' => $subtotal,
                'id_user' => $this->input->post('id_user')
            ];

            $this->db->insert('v_cart', $data);
            
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">
            New item added!
            </div>');
            redirect('user/transaksi');
        }

    }

    public function transaksi()
    {
        $data['title'] = 'Transaksi';
        $data['tbl_user'] = $this->db->get_where('tbl_user', ['email' => $this->session->userdata('email')])->row_array();
        
        $data['barang'] = $this->db->get('tbl_obat')->result_array();
        $data['produk'] = $this->db->get('v_cart')->result_array();

        $this->form_validation->set_rules('bayar', 'Bayar', 'trim|required');
        
        if ( $this->form_validation->run() == false ) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('user/transaksi', $data);
            $this->load->view('templates/footer');   
        } else {
            if ($this->input->post('bayar') > $this->input->post('total') ) {
            $stok = $this->input->post('stok');
            $qty = $this->input->post('qty');
            $id_obat = $this->input->post('id_obat');
            $bayar = $this->input->post('bayar');
            $update = $stok-$qty;
            $data = [
                'tanggal' => time(),
                'diskon' => $this->input->post('diskon'),
                'bayar' => $bayar
            ];

            $this->db->insert('transaksi', $data);

            $this->db->set('stok', $update);
            $this->db->where('id_obat', $id_obat);
            $this->db->update('tbl_obat');

            redirect('user/transaksi');
            }
            redirect('user/transaksi');

        }
    }

    public function hapus($id)
    {
        $this->um->hapusProduct($id);

        redirect('user/transaksi');
    }

    public function profile()
    {
        $data['title'] = 'My Profile';
        $data['tbl_user'] = $this->db->get_where('tbl_user', ['email' => $this->session->userdata('email')])->row_array();
        
        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('user/profile', $data);
        $this->load->view('templates/footer');
    }

}

