
  
  <!-- Header -->
  <div class="header bg-gradient-primary pb-8 pt-5 pt-md-8">
      <div class="container-fluid">
        <div class="header-body">
          <!-- Card stats -->
          <div class="row">
                
          </div>
        </div>
      </div>
    </div>
    <div class="container-fluid">
        <h1 class="text-left my-3">
            <?= $title; ?>
        </h1>   
        <div class="row">
            <div class="col-lg">
            
            <?= $this->session->flashdata('message'); ?>

            <?= form_error('menu', '<div class="alert alert-danger" role="alert">', '</div>'); ?> 

                <a href="" class="btn btn-primary mb-3" data-toggle="modal" data-target="#newSubMenuModal">Add New Submenu</a>

                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Title</th>
                            <th scope="col">Menu</th>
                            <th scope="col">Url</th>
                            <th scope="col">Icon</th>
                            <th scope="col">Active</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Title</th>
                            <th scope="col">Menu</th>
                            <th scope="col">Url</th>
                            <th scope="col">Icon</th>
                            <th scope="col">Active</th>
                            <th scope="col">Action</th>
                        </tr>
                    </tfoot>
                    <tbody>
                    <?php $i = 1; ?>
                    <?php foreach($subMenu as $sm) : ?>
                        <tr>
                            <th scope="row"><?= $i; ?></th>
                            <td><?= $sm['title']; ?></td>          
                            <td><?= $sm['menu']; ?></td>       
                            <td><?= $sm['url']; ?></td>        
                            <td><?= $sm['icon']; ?></td>
                            <td class="text-center"><?= $sm['is_active']; ?></td>
                            <td class="text-center">
                                <div class="dropdown">
                                    <a class="btn btn-sm btn-icon-only text-light" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <i class="fas fa-ellipsis-v"></i>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow text-center">
                                        <a href="<?= base_url(); ?>menu/edit/<?= $sm['id']; ?>" class="badge badge-success">edit</a>
                                        <a href="<?= base_url(); ?>menu/hapus/<?= $sm['id']; ?>" id="tombol" class="badge badge-danger">delete</a>
                                    </div>
                                </div>
                            </td>                                                      
                        </tr>
                    <?php $i++; ?>    
                    <?php endforeach; ?>
                    </tbody>
                </table>           
            </div>
        </div>
    </div>

<!-- Modal -->
<div class="modal fade" id="newSubMenuModal" tabindex="-1" role="dialog" aria-labelledby="newSubMenuModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="newSubMenuModalLabel">Add New Submenu</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <form action="<?= base_url('menu/submenu'); ?>" method="post">
            <div class="modal-body">
                <div class="form-group <?= form_error('title') ? 'has-error' : null ?>">
                    <input type="text" class="form-control" id="title" name="title" placeholder="Submenu title">
                    <small class="text-danger"><?= form_error('title'); ?></small>
                </div>
                <div class="form-group <?= form_error('menu_id') ? 'has-error' : null ?>">
                    <select name="menu_id" id="menu_id" class="form-control">
                        <option value="">-- Select Menu --</option>
                        <?php foreach($menu as $m) : ?>
                        <option value="<?= $m['id']; ?>"><?= $m['menu']; ?></option>
                        <?php endforeach; ?>
                    </select>
                    <small class="text-danger"><?= form_error('menu_id'); ?></small>
                </div>
                <div class="form-group <?= form_error('url') ? 'has-error' : null ?>">
                    <input type="text" class="form-control" id="url" name="url" placeholder="Submenu url">
                    <small class="text-danger"><?= form_error('url'); ?></small>
                </div>
                <div class="form-group <?= form_error('icon') ? 'has-error' : null ?>">
                    <input type="text" class="form-control" id="icon" name="icon" placeholder="Submenu icon">
                    <small class="text-danger"><?= form_error('icon'); ?></small>
                </div>
                <div class="form-group">
                    <div class="form-check">
                        <input type="checkbox" class="form-check-input" value="1" name="is_active" di="is_active" checked>
                        <label for="is_active" class="form-check-label">
                            Active?
                        </label>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Add</button>
            </div>
        </form>
    </div>
  </div>
</div>