<nav class="navbar navbar-vertical fixed-left navbar-expand-md navbar-light bg-white" id="sidenav-main">
    <div class="container-fluid">
      <!-- Toggler -->
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#sidenav-collapse-main" aria-controls="sidenav-main" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <!-- Brand -->
      <a class="navbar-brand pt-0" href="<?= base_url('admin'); ?>">
        <img src="<?= base_url('assets'); ?>/img/brand/brand.png" class="navbar-brand-img" alt="...">
      </a>
      <!-- Collapse -->
      <div class="collapse navbar-collapse" id="sidenav-collapse-main">
        <!-- Collapse header -->
        <div class="navbar-collapse-header d-md-none">
          <div class="row">
            <div class="col-6 collapse-brand">
              <a href="./index.html">
                <img src="<?= base_url('assets'); ?>/img/brand/brand.png">
              </a>
            </div>
            <div class="col-6 collapse-close">
              <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#sidenav-collapse-main" aria-controls="sidenav-main" aria-expanded="false" aria-label="Toggle sidenav">
                <span></span>
                <span></span>
              </button>
            </div>
          </div>
        </div>

        <!-- Query Menu -->
        <?php 

          $role_id = $this->session->userdata('role_id');
          $queryMenu = "SELECT `user_menu`.`id`, `menu`
                          FROM `user_menu` JOIN `user_access_menu` 
                            ON `user_menu`.`id` = `user_access_menu`.`menu_id`
                        WHERE `user_access_menu`.`role_id` = $role_id
                        ORDER BY `user_access_menu`.`menu_id` ASC
                      ";

          $menu = $this->db->query($queryMenu)->result_array();            

        ?>

        <!-- Looping Menu -->
        <?php foreach ( $menu as $m ) : ?>
        <h6 class="navbar-heading text-muted">
            <?= $m['menu']; ?>
        </h6>

        <!-- Siapkan Sub-Menu Sesuai Menu -->
        <?php 
        
          $menuId = $m['id'];
          $querySubMenu = "SELECT *
                            FROM `user_sub_menu` JOIN `user_menu` 
                              ON `user_sub_menu`.`menu_id` = `user_menu`.`id`
                          WHERE `user_sub_menu`.`menu_id` = $menuId
                          AND `user_sub_menu`.`is_active` = 1
                        ";
          $subMenu   = $this->db->query($querySubMenu)->result_array();            

        ?>

          <?php foreach( $subMenu as $sm ) : ?>
              <ul class="navbar-nav">
                  <?php if( $title == $sm['title'] ) : ?>
                    <li class="nav-item active">
                  <?php else : ?>
                    <li class="nav-item">
                  <?php endif; ?>
                    <a class=" nav-link pb-0" href="<?= base_url($sm['url']); ?>"> 
                    <i class="<?= $sm['icon']; ?>"></i>
                      <?= $sm['title']; ?>
                    </a>
                  </li>
              </ul>
          <?php endforeach; ?> 

                  <hr class="my-2">

        <?php endforeach; ?>  
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link active" href="<?= base_url('auth/logout'); ?>">
                  <i class="ni ni-user-run"></i> Logout
                </a>
            </li>
        </ul>
      </div>
    </div>
  </nav>