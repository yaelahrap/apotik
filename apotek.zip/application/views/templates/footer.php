<footer class="py-5">
      <div class="container">
        <div class="row align-items-center justify-content-xl-between">
          <div class="col-xl-6">
            <div class="copyright text-center text-xl-left text-muted">
              Copyright &copy; <a href="#" class="font-weight-bold ml-1" target="_blank">Development Tim</a> <?= date('Y'); ?>
            </div>
          </div>
        </div>
      </div>
    </footer>
  </div>
</div>
  <!--   Core   -->
  <script src="<?= base_url('assets'); ?>/js/plugins/jquery/dist/jquery.min.js"></script>
  <script src="<?= base_url('assets'); ?>/js/plugins/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <!--   Optional JS   -->
  <script src="<?= base_url('assets'); ?>/js/plugins/chart.js/dist/Chart.min.js"></script>
  <script src="<?= base_url('assets'); ?>/js/plugins/chart.js/dist/Chart.extension.js"></script>
  <!--   Argon JS   -->
  <script src="<?= base_url('assets'); ?>/js/argon-dashboard.min.js?v=1.1.0"></script>
  <script src="https://cdn.trackjs.com/agent/v3/latest/t.js"></script>
  <!-- Sweet Alert -->
  <script src="<?= base_url('assets'); ?>/js/sweetalert2.all.min.js"></script>
  <script src="<?= base_url('assets'); ?>/js/sweetalertlo.js"></script>
  <script>
    window.TrackJS &&
      TrackJS.install({
        token: "ee6fab19c5a04ac1a32a645abde4613a",
        application: "argon-dashboard-free"
      });
  </script>
  <script>

     $('.custom-file-input').on('change', function() {
        let fileName = $(this).val().split('\\').pop();
        $(this).next('.custom-file-label').addClass("selected").html(fileName);
     }); 
    
      $('.custom-control-input').on('click', function() {
          const menuId = $(this).data('menu');
          const roleId = $(this).data('role');

          $.ajax({
              url: "<?= base_url('admin/changeaccess'); ?>",
              type: 'post',
              data: {
                  menuId: menuId,
                  roleId: roleId
              },
              success: function() {
                  document.location.href = "<?= base_url('admin/roleaccess/'); ?>" + roleId;
              }
          });
      });

  </script>
</body>

</html>