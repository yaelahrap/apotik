
  
  <!-- Header -->
  <div class="header bg-gradient-primary pb-8 pt-5 pt-md-8">
      <div class="container-fluid">
        <div class="header-body">
          <!-- Card stats -->
          <div class="row">
                
          </div>
        </div>
      </div>
    </div>
    <div class="container-fluid">
        <h1 class="text-left my-3">
            <?= $title; ?>
        </h1>   
        <div class="row">
            <div class="col-lg">

            <?= form_error('menu', '<div class="alert alert-danger" role="alert">', '</div>'); ?> 

            <?= $this->session->flashdata('message'); ?>

                <a href="" class="btn btn-primary mb-3" data-toggle="modal" data-target="#newMedicineModal">Add New Medicine</a>

                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Nama</th>
                            <th scope="col">Satuan</th>
                            <th scope="col">Harga</th>
                            <th scope="col">Stock</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Nama</th>
                            <th scope="col">Satuan</th>
                            <th scope="col">Harga</th>
                            <th scope="col">Stock</th>
                            <th scope="col">Action</th>
                        </tr>
                    </tfoot>
                    <tbody>
                    <?php $i = 1; ?>
                    <?php foreach($nama_obat as $medic) : ?>
                        <tr>
                            <th scope="row"><?= $i; ?></th>
                            <td><?= $medic['nama_obat']; ?></td>          
                            <td><?= $medic['satuan']; ?></td>          
                            <td><?= $medic['harga']; ?> IDR</td>          
                            <td><?= $medic['stok']; ?></td>          
                            <td>
                                <div class="dropdown">
                                    <a class="btn btn-sm btn-icon-only text-light" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <i class="fas fa-ellipsis-v"></i>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow text-center">
                                        <a href="<?= base_url(); ?>user/edit/<?= $medic['id_obat']; ?>" class="badge badge-success">edit</a>
                                        <a href="<?= base_url(); ?>user/hapus/<?= $medic['id_obat']; ?>" class="badge badge-danger" onclick="return confirm('yakin?');">delete</a>
                                    </div>
                                </div>
                            </td>                                                      
                        </tr>
                    <?php $i++; ?>    
                    <?php endforeach; ?>
                    </tbody>
                </table>           
            </div>
        </div>
    </div>

<!-- Modal -->
<div class="modal fade" id="newMedicineModal" tabindex="-1" role="dialog" aria-labelledby="newMedicineModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="newMedicineModalLabel">Add New Medicine</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <form action="<?= base_url('user/medicine'); ?>" method="post">
            <div class="modal-body">
                <div class="form-group <?= form_error('nama_obat') ? 'has-error' : null ?>">
                    <input type="text" class="form-control" id="nama_obat" name="nama_obat" placeholder="Medicine Name">
                    <small class="text-danger"><?= form_error('nama_obat'); ?></small>
                </div>
            </div>
            <div class="modal-body">
                <div class="form-group <?= form_error('satuan') ? 'has-error' : null ?>">
                    <select class="form-control" name="satuan" id="satuan">
                        <option value="">-- Pilih Satuan --</option>
                        <option value="Tablet">Tablet</option>
                        <option value="Botol">Botol</option>
                    </select>
                    <small class="text-danger"><?= form_error('satuan'); ?></small>
                </div>
            </div>
            <div class="modal-body">
                <div class="form-group <?= form_error('harga') ? 'has-error' : null ?>">
                    <input type="number" class="form-control" id="harga" name="harga" placeholder="Harga">
                    <small class="text-danger"><?= form_error('harga'); ?></small>
                </div>
            </div>
            <div class="modal-body">
                <div class="form-group <?= form_error('stok') ? 'has-error' : null ?>">
                    <input type="number" class="form-control" id="stok" name="stok" placeholder="Stock">
                    <small class="text-danger"><?= form_error('stok'); ?></small>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Add</button>
            </div>
        </form>
    </div>
  </div>
</div>