
  
  <!-- Header -->
  <div class="header bg-gradient-primary pb-8 pt-5 pt-md-8">
      <div class="container-fluid">
        <div class="header-body">
          <!-- Card stats -->
          <div class="row">
              
          </div>
        </div>
      </div>
    </div>
    <div class="container">
        <h1 class="text-left my-3">
            <?= $title; ?>
        </h1>
        <div class="row">
            <div class="col-lg">
            <?= $this->session->flashdata('message'); ?>
        </div>
    </div>
    <div class="card card-stats mb-4 mb-xl-0">
            <div class="card-body">
                <button class="btn btn-primary" data-toggle="modal" data-target="#exampleModal"><i class="fa fa-fw fa-plus"></i> Produk</button>
            </div>
        </div>
        <div class="card card-stats mb-4 mb-xl-0 my-4">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table align-items-center table-flush">
                            <thead class="thead-light">
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Nama Produk</th>
                                    <th scope="col">Harga Satuan</th>
                                    <th scope="col">Qty</th>
                                    <th scope="col">Diskon</th>
                                    <th scope="col">Subtotal</th>
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <tfoot class="thead-light">
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Nama Produk</th>
                                    <th scope="col">Harga Satuan</th>
                                    <th scope="col">Qty</th>
                                    <th scope="col">Diskon</th>
                                    <th scope="col">Subtotal</th>
                                    <th scope="col">Action</th>
                                </tr>
                            </tfoot>
                            <tbody>
                            <?php 
                            $i = 1;
                            $total = 0;
                             ?>
                            <?php foreach($produk as $cart) : ?>
                                <tr>
                                    <th scope="col"><?= $i++; ?></th>
                                    <td><?= $cart['nama_obat']; ?></td>
                                    <td><?= $cart['harga']; ?> IDR</td>
                                    <td><?= $cart['qty']; ?></td>
                                    <td>-</td>
                                    <td><?= $cart['subtotal']; ?> IDR</td>
                                    <td>
                                    <a href="<?= base_url(); ?>user/hapus/<?= $cart['id']; ?>" class="badge badge-danger" onclick="return confirm('yakin?');">delete</a>
                                    </td>
                                </tr>
                                <?php $total += (int) $cart['subtotal']; ?>
                            <?php endforeach; ?>    
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <form action="<?= base_url('user/transaksi') ?>" method="post">
                <div class="form-group lg-4">
                    <div class="card card-stats mb-4 mb-xl-0 my-4">
                        <div class="card-body">
                            <div class="pl-lg-4">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label class="form-control-label" for="total">Total</label>
                                            <input type="number" id="total" name="total" class="form-control form-control-alternative" value="<?= $total; ?>" readonly>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label class="form-control-label" for="kembali">Kembali</label>
                                            <input type="number" id="kembali" name="kembali" class="form-control form-control-alternative" readonly>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="form-group <?= form_error('bayar') ? 'has-error' : null ?>">
                                            <label class="form-control-label" for="bayar">Bayar</label>
                                            <input type="hidden" name="total" value="<?= $total; ?>" >
                                            <input type="number" id="bayar" name="bayar" min="<?= $total; ?>" class="form-control form-control-alternative" onkeyup="document.getElementById('kembali').value = parseInt(document.getElementById('bayar').value) - parseInt(document.getElementById('total').value)">
                                            <small class="text-danger"><?= form_error('bayar'); ?></small>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label class="form-control-label" for="diskon">Diskon</label>
                                            <input type="number" name="diskon" id="diskon" class="form-control form-control-alternative" placeholder="0">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <button type="submit" name="submit" class="btn btn-primary text-right my-3"> Bayar</button>
            </form>
<script>
</script>
<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div class="table responsive">
            <table class="table table-hover">
            <thead class="thead-light">
                <tr>
                    <th scope="col">Produk</th>
                    <th scope="col">Harga Satuan</th>
                    <th scope="col">Stok</th>
                    <th class="text-center" scope="col">Qty</th>
                </tr>
            </thead>
            <tfoot class="thead-light">
                <tr>
                    <th scope="col">Produk</th>
                    <th scope="col">Harga Satuan</th>
                    <th scope="col">Stok</th>
                    <th class="text-center" scope="col">Qty</th>
                </tr>
            </tfoot>
            <tbody>
                <?php foreach($barang as $b) : ?>
                <tr>
                    <td><?= $b['nama_obat']; ?></td>
                    <td><?= $b['harga']; ?></td>
                    <td><?= $b['stok']; ?></td>
                    <form action="<?= base_url('user/addcart'); ?>" method="post" class="form-inline">
                        <input type="hidden" name="id_obat" value="<?= $b['id_obat']; ?>">
                        <input type="hidden" name="nama_obat" value="<?= $b['nama_obat']; ?>">
                        <input type="hidden" name="harga" value="<?= $b['harga']; ?>">
                        <input type="hidden" name="stok" value="<?= $b['stok']; ?>">
                        <input type="hidden" name="id_user" value="<?= $tbl_user['id']; ?>">
                        <td>
                            <div class="form-group <?= form_error('nama_obat') ? 'has-error' : null ?>">
                                <input class="form-control" type="number" name="qty" placeholder="Qty" autocomplete="off">
                                <small class="text-danger"><?= form_error('nama_obat'); ?></small>
                            </div>
                        </td>
                    </form>
                </tr>
                <?php endforeach; ?>
            </td>
            </table>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>