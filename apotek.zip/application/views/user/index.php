
  
  <!-- Header -->
    <div class="header bg-gradient-primary pb-8 pt-5 pt-md-8">
      <div class="container-fluid">
        <div class="header-body">
          <!-- Card stats -->
          <div class="row">
              
          </div>
        </div>
      </div>
    </div>
        <div class="container-fluid">
        <h1 class="text-left my-3">
            <?= $title; ?>
        </h1>
        <div class="row">
          <div class="col-lg-6">
            <?= $this->session->flashdata('message'); ?>
          </div>
        </div>

            <div class="card mb-3 my-3" style="max-width: 540px;">
                <div class="row no-gutters">
                    <div class="col-md-4">
                    <img src="<?= base_url('assets/img/profile/') . $tbl_user['image']; ?>" class="card-img">
                    </div>
                    <div class="col-md-8">
                    <div class="card-body">
                        <h5 class="card-title"><?= $tbl_user['name']; ?></h5>
                        <p class="card-text"><?= $tbl_user['email']; ?></p>
                        <p class="card-text"><small class="text-muted">Member since <?= date('d F Y', $tbl_user['date_created']); ?></small></p>
                    </div>
                </div>
            </div>
        </div>
    </div>