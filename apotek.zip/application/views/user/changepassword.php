
  
  <!-- Header -->
  <div class="header bg-gradient-primary pb-8 pt-5 pt-md-8">
      <div class="container-fluid">
        <div class="header-body">
          <!-- Card stats -->
          <div class="row">
                
          </div>
        </div>
      </div>
    </div>
    <div class="container-fluid">
        <h1 class="text-left my-3">
            <?= $title; ?>
        </h1>
    <div class="row">
        <div class="col-lg-6">
            <?= $this->session->flashdata('message'); ?>
            <form action="<?= base_url('user/changepassword'); ?>" method="post">
                <div class="from-group">
                    <div class="col-sm-10 my-3">
                        <input type="password" class="form-control" id="current_password" name="current_password" placeholder="Current Password">
                        <?= form_error('current_password', '<small class="text-danger ">', '</small>'); ?>
                    </div>
                </div>
                <div class="from-group">
                    <div class="col-sm-10 my-3">
                        <input type="password" class="form-control" id="new_password1" name="new_password1" placeholder="New Password">
                        <?= form_error('new_password1', '<small class="text-danger ">', '</small>'); ?>
                    </div>
                </div>
                <div class="from-group">
                    <div class="col-sm-10 my-3">
                        <input type="password" class="form-control" id="new_password2" name="new_password2" placeholder="Repeat Password">
                        <?= form_error('new_password2', '<small class="text-danger ">', '</small>'); ?>
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-10 my-3">
                        <button type="submit" class="btn btn-primary">Change Password</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
