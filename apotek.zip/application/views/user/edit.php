
  
  <!-- Header -->
  <div class="header bg-gradient-primary pb-8 pt-5 pt-md-8">
      <div class="container-fluid">
        <div class="header-body">
          <!-- Card stats -->
          <div class="row">
                
          </div>
        </div>
      </div>
    </div>
    <div class="container-fluid">
        <h1 class="text-left my-3">
            <?= $title; ?>
        </h1>

        <div class="row">
            <div class="col-lg-8">
                <?= form_open_multipart('user/edit'); ?>
                    <div class="from-group">
                        <div class="col-sm-10 my-3">
                            <input type="text" class="form-control" id="email" name="email" value="<?= $tbl_user['email']; ?>" readonly>
                        </div>
                    </div>
                    <div class="from-group">
                        <div class="col-sm-10 my-3">
                            <input type="text" class="form-control" id="name" name="name" placeholder="Full name..." value="<?= $tbl_user['name']; ?>">
                            <?= form_error('name', '<small class="text-danger pl-3">', '</small>'); ?>
                        </div>
                    </div>
                    <div class="from-group">
                        <div class="col-sm-10">
                            <div class="row">
                                <div class="col-sm-3 mb-3">
                                    <img src="<?= base_url('assets/img/profile/') . $tbl_user['image']; ?>" class="img-thumbnail">
                                </div>
                                <div class="col-sm-9">
                                    <div class="custom-file">
                                        <input type="file" class="custom-file-input" id="image" name="image">
                                        <label for="image" class="custom-file-label">
                                            Choose file
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-group justify-content-end">
                        <div class="col-sm-10">
                            <button type="submit" class="btn btn-primary">Edit</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>