
  
  <!-- Header -->
  <div class="header bg-gradient-primary pb-8 pt-5 pt-md-8">
      <div class="container-fluid">
        <div class="header-body">
          <!-- Card stats -->
          <div class="row">
                
          </div>
        </div>
      </div>
    </div>
    <div class="container-fluid">
        <h1 class="text-left my-3">
            <?= $title; ?>
        </h1>   
        <div class="row">
            <div class="col-lg-6">

            <?= $this->session->flashdata('message'); ?>

                <h5>Role : <?= $role['role']; ?></h5>

                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Menu</th>
                            <th scope="col">Access</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Menu</th>
                            <th scope="col">Access</th>
                        </tr>
                    </tfoot>
                    <tbody>
                    <?php $i = 1; ?>
                    <?php foreach($menu as $m) : ?>
                        <tr>
                            <th scope="row"><?= $i; ?></th>
                            <td><?= $m['menu']; ?></td>          
                            <td>
                                <div class="custom-control custom-control-alternative custom-checkbox">
                                    <input class="custom-control-input" id=" customCheckLogin" type="checkbox" <?= check_access($role['id'], $m['id']); ?> data-role="<?= $role['id']; ?>" data-menu="<?= $m['id']; ?>">
                                    <label class="custom-control-label pb-3" for=" customCheckLogin"></label>
                                </div>
                            </td>                  
                        </tr>
                    <?php $i++; ?>    
                    <?php endforeach; ?>
                    </tbody>
                </table>
                <a href="<?= base_url('admin/role'); ?> " class="btn btn-sm btn-primary">Back</a>     
            </div>
        </div>
    </div>